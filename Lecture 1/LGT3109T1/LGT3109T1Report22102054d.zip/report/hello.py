your_name = input("What's your name? ")
your_id = input("What's your student id? ")
greeting_message = "Hello " + your_name + " (id: " + your_id + ")!"
print(greeting_message)
